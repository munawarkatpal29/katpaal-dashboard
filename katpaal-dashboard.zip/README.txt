Katpaal Links Dashboard - Installation Guide
============================================

1. DATABASE SETUP:
   - Create MySQL database named: katpaal_dashboard
   - Import database.sql file

2. CONFIGURATION:
   - Edit config.php with your MySQL credentials
   - Update: $username, $password

3. UPLOAD FILES:
   - Upload all PHP files to your web server

4. ACCESS:
   - Visit: yourdomain.com/login.php
   - Demo credentials:
        Username: admin
        Password: admin123

5. FEATURES:
   - User registration and login
   - Multiple dashboards
   - Drag and drop shortcuts
   - Responsive design
   - Secure authentication

6. FILES INCLUDED:
   - config.php (Database configuration)
   - index.php (Main dashboard)
   - login.php (Login page)
   - signup.php (Registration page)
   - ajax.php (AJAX handlers)
   - database.sql (Database structure)

For support, contact your developer.